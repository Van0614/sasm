import React from 'react';

export default function Blog(){
  return(
    <>
      <div>This is Blog Page</div>
      <ul>
        <li>Blog 1</li>
        <li>Blog 2</li>
      </ul>
    </>
  )
};